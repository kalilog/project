# Define the Flight class to represent a flight entity
class Flight:
    # Constructor to initialize flight attributes: origin, number, airline
    def __init__(self, origin, number, airline, arrival):
        self.origin = origin
        self.number = number
        self.airline = airline
        self.arrival = arrival

    # Method to display flight information
    def information(self):
        print("Flight origin is " + self.origin)
        print("Flight number is " + str(self.number))
        print("Airline is " + self.airline)
        print("Arrival time is " + str(self.arrival))

# Define the available_flights() function
def available_flights():
    # Create instances of Flight for available flights
    flight1 = Flight("Kuwait", 1000, "Kuwait Airways" , 10.09)
    flight2 = Flight("London", 1001, "British Airways" , 5.00)
    flight3 = Flight("Japan", 1002, "Japan Airways" , 7.30)
    flight4 = Flight("dubai" , 1003 , "Etihad Airways" , 3.56)

    # Display available flights and their details
    print("1. Kuwait")
    print("2. London")
    print("3. Japan")
    print("4. Dubai")

    # Prompt the user to select a flight
    booking_info = int(input("Please select a flight: "))

    # Display the selected flight's information using the information() method
    if booking_info == 1:
        flight1.information()

    elif booking_info == 2:
        flight2.information()

    elif booking_info == 3:
        flight3.information()

    elif booking_info == 4 :
        flight4.information()

    else:
        print("Invalid choice. Please select a valid flight.")

# Define the book_flight() function
def book_flight():
    # Store available cities in a dictionary
    available_cities = {
        "Kuwait": 1,
        "London": 2,
        "Japan": 3,
        "Dubai" : 4,
    }

    # Display available cities for booking
    print("1. Kuwait")
    print("2. London")
    print("3. Japan")
    print("4. Dubai")

    # Prompt the user if they want to book a flight
    book_choice = input("Do you want to book a flight? (Yes/No)\n")

    # If the user wants to book, repeatedly prompt for the city name until a valid city is entered
    if book_choice.lower() == "yes":

        while True:

            user_city = input("Enter the name of the city: ").capitalize()

            if user_city in available_cities:
                print(f"You have booked a flight to {user_city}")
                print("Thank you!")
                break

            else:
                print("Error: Invalid city name. Please choose from the available cities.")
    else:
        print("You will go back to the main menu, please try again")

# Main Loop
while True:
    print("\nWelcome to our website")
    a = int(input("If you want to proceed please click 1: "))

    # Check if the user wants to proceed
    if a == 1:
        print("Here is our menu")
        print("1. Available flights")
        print("2. Book a flight")
        print("3. Exit")

        try:
            # Get user's choice
            choice = int(input("Please enter a choice: "))

            # Execute corresponding functions based on user's choice
            if choice == 1:
                available_flights()
            elif choice == 2:
                book_flight()
            elif choice == 3:
                print("Bye!")
                break
            else:
                print("Try again. Please enter a valid choice")

        except ValueError:
            print("Invalid input. Please enter a number.")
    else:
        break  # Exit the loop if user doesn't want to proceed
